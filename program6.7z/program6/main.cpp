#include <iostream>
#include <utility>
#include <algorithm>

#include <QApplication>
#include <QWidget>

#include <qwt/qwt_plot.h>
#include <qwt/qwt_plot_curve.h>
#include <qwt/qwt_point_data.h>
#include <qwt/qwt_painter.h>

std::istream &operator>>(std::istream &is, std::pair<double, double> &point){
    is>>point.first;
    is>>point.second;

    return is;
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QWidget okno;
    okno.setWindowTitle("Dopasowanie MNK");
    okno.setFixedSize(800, 600);

    std::vector<double> x, y;

    std::pair<double, double> points_temp;
    while (std::cin>>points_temp) {
        x.push_back(points_temp.first);
        y.push_back(points_temp.second);
    }

    std::vector<double>::iterator max_x, min_x, max_y, min_y;

    max_x = std::max_element(x.begin(), x.end());
    min_x = std::min_element(x.begin(), x.end());
    max_y = std::max_element(y.begin(), y.end());
    min_y = std::min_element(y.begin(), y.end());

    QwtPlot wykres (&okno);
    wykres.setTitle("Dopasowanie MNK");
    wykres.setAxisTitle(QwtPlot::xBottom, "Nr kanału");
    wykres.setAxisTitle(QwtPlot::yLeft, "Napięcie /V");
    wykres.setFixedSize(775,575);
    wykres.setCanvasBackground(QBrush(QColor(0xff,0xfa,0x6b)));
    wykres.setAxisScale(QwtPlot::xBottom, *min_x, *max_x);
    wykres.setAxisScale(QwtPlot::yLeft, *min_y, *max_y);

    QwtPlotCurve dane_doswiadczalne;
    dane_doswiadczalne.setRawSamples(x.data(),y.data(),x.size());
    dane_doswiadczalne.setStyle(QwtPlotCurve::Dots);
    dane_doswiadczalne.setPen(QPen(Qt::blue, 3));
    dane_doswiadczalne.attach(&wykres);

    double delta, X_2=0, XY=0, x_sume=0, y_sume=0, A, B;
    for(size_t i = 0; i< x.size();i++){
        X_2+=pow(x[i],2);
        x_sume+=x[i];
        y_sume+=y[i];
        XY+=(x[i]*y[i]);
    }

    delta=x.size()*X_2-pow(x_sume,2);
    B=(x.size()*XY-y_sume*x_sume)/delta;
    A=(y_sume*X_2-x_sume*XY)/delta;

    std::vector<double> mnk_x, mnk_y;

    for(double x_temp = *min_x; x_temp < *max_x; x_temp+=(*max_x-*min_x)/10.0){
        mnk_x.push_back(x_temp);
        mnk_y.push_back(A*x_temp+B);
    }

    QwtPlotCurve mnk;
    mnk.setRawSamples(mnk_x.data(),mnk_y.data(),mnk_x.size());
    mnk.setStyle(QwtPlotCurve::Lines);
    mnk.setPen(QPen(Qt::red, 2));
    mnk.attach(&wykres);

    okno.show();

    return app.exec();
}
